<!-- Footer -->
    <footer class="footer" style="background-color: #a2b6df">
        &copy <?php echo date("Y");?> <a href="http://about.me/jcsoftia" target="_blank">jcsoftia</a>  <span class="d-none d-sm-inline-block"> - Creado con  <i class="mdi mdi-heart text-danger"></i> por Juan Carlos Valencia López</span>.
    </footer>

    <!-- End Footer -->
