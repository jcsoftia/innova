<?php
 header("Location: public")
?>