<div class="error-bg"></div>

<?php $__env->startSection('title', __('Página no encontrada') ); ?>

<?php $__env->startSection('code'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('message'); ?>
        <link rel="stylesheet" href="./assets/css/plantilla.css">
        <!-- Begin page -->
        <div class="home-btn d-none d-sm-block">
                                            <a href="/" class="text-white"><i class="fas fa-home h2"></i></a>
                                        </div>
        
            <div class="account-pages">
            
                <div class="container">
                    <div class="row justify-content-center">
                            <div class="card shadow-lg">
                                <div class="card-block">
                                    
                                    <div class="text-center p-3">
                                        
                                            <h1 class="error-page mt-4"><span>404!</span></h1>
                                        <h4 class="mb-4 mt-5">Página no disponible</h4>
                                        <p class="mb-4">Lo siento, esta página no está disponible.<br> Ha sido eliminada o nunca existió.</p>
                                        
                                        <a class="btn btn-primary mb-4 waves-effect waves-light" href="/"><i class="mdi mdi-home"></i> Ir al inicio</a>
                                    </div>
                
                                </div>
                            </div>
                                                
                        </div>
                    </div>
                    <!-- end row -->
                </div>
            </div>
        <!-- END wrapper -->
        <script src="./js/plantilla.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/juancarlos/Escritorio/innova_dent/resources/views/errors/404.blade.php ENDPATH**/ ?>